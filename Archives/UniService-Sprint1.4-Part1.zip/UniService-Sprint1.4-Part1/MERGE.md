# Merge Instructions

Prerequisite:
Merge this package into your existing UniService project.

1. Copy backend/, docker/, docs/ into the project root.
2. Merge folders.
3. Replace files ONLY when the path is identical.
4. Do NOT delete previous Flyway migrations.
5. Run:
   mvn clean install
   npm install
6. Verify:
   mvn spring-boot:run
