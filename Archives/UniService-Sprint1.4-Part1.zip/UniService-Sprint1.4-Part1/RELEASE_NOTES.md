# UniService Sprint 1.4 Part 1

This release replaces the earlier prototype approach with a production-oriented
project foundation.

Highlights:
- Maven dependencies skeleton
- Improved application.yml
- Docker Compose
- Environment template
- Merge instructions
