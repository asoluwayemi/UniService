Copy backend/, frontend/, docs/ into your existing UniService project.
Merge folders.
Run:
mvn clean install
npm install
