# Sprint 1.3
Adds authentication domain model scaffolding and merge guide.
