# Merge Instructions

1. Extract this package.
2. Copy the backend/, frontend/, and docs/ folders into your existing UniService project.
3. Allow folder merge.
4. Replace files ONLY if they already exist with the same name from previous authentication work.
5. Run:
   mvn clean install
   npm install
6. Flyway will detect new migrations automatically.
