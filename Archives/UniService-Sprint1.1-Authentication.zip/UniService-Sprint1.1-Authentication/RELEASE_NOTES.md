# Sprint 1.1 - Authentication Foundation

Included:
- Auth package structure
- Repository interfaces
- DTOs
- Controller skeleton
- Security placeholders
- Merge guide
