import React from 'react';
import ReactDOM from 'react-dom/client';

function App(){
  return <h1>Welcome to UniService</h1>;
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
